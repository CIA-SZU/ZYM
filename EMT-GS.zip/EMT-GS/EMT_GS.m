function [IGD, population]=EMT_GS(Tasks,pop,gen,index)
% Rotation Matrix : M
generation = 1;
pop1=pop/2;
pop2=pop1;
if mod(pop,2)~=0
    pop=pop+1;
    pop2=pop2+1;
end

dim1=Tasks(1).dim;
dim2=Tasks(2).dim;
dim=max([dim1,dim2]);
for i=1:pop
    population(i)=Chromosome2;
    population(i)=initialize(population(i),dim);
    if i<=pop1
        population(i).skill_factor=1;
    else
        population(i).skill_factor=2;
    end
    [population(i).obj(1) , population(i).obj(2)] = evaluate(population(i),Tasks(population(i).skill_factor));
end

for i = 1:2
    popobj = [];
    population_subpop =population([population.skill_factor]==i);   %ѡ������Ⱥ
    for j = 1:length(population_subpop)
        popobj(j,:) = population_subpop(j).obj;
    end
    [front, FrontNO,~] = NDSort(popobj,inf);
    for j = 1:length(population_subpop)
        population_subpop(j).front = FrontNO(j);
    end
    %crowing distance
    [population_subpop,~]=SolutionComparison.diversity(population_subpop,front,length(population_subpop...
        ),length(population_subpop(1).obj));
    population((i-1) * (pop1) +1 : i*(pop1)) = population_subpop;
end
prepop = population;
while generation <= gen
    % using GAN
    if mod(generation ,10) == 0
        GAN_flag = 1;
    else
        GAN_flag = 0;
    end
    population_t1 = population(1:pop1);
    population_t2 = population(pop1+1:end);
    %ѵ��GANs
    if GAN_flag == 1 || generation==1
        population_t1_matrix = [population_t1(1:end).rnvec];
        population_t1_matrix = vec2mat(population_t1_matrix , dim);
        curent_t1 = population_t1_matrix';
        population_t2_matrix = [population_t2(1:end).rnvec];
        population_t2_matrix = vec2mat(population_t2_matrix , dim);
        curent_t2 = population_t2_matrix';
        [GAN_child_t21 , GAN_2_1,setG21] = GAN(curent_t2, curent_t1);
        [GAN_child_t12 , GAN_1_2,setG12] = GAN(curent_t1, curent_t2);
        
    else
        population_t2_matrix = [population_t2(1:end).rnvec];
        population_t2_matrix = vec2mat(population_t2_matrix , dim);
        data = population_t2_matrix';
        if rand(1)>0.5
            GAN_child_t12 = GGenerator(data,GAN_1_2,setG12);
        else
            params = setG21;
            GAN_child_t12 = GGenerator(data,GAN_1_2,params);
        end
        population_t1_matrix = [population_t1(1:end).rnvec];
        population_t1_matrix = vec2mat(population_t1_matrix , dim);
        data = population_t1_matrix';
        if rand(1)>0.5
            GAN_child_t21 =  GGenerator(data,GAN_2_1,setG21);
        else
            params = setG12;
            GAN_child_t21 =  GGenerator(data,GAN_2_1,params);
        end
    end
    GAN_t12 = population(1:pop1);
    GAN_t21 = population(1:pop1);
    GAN_child_t21=GAN_child_t21';
    GAN_child_t12=GAN_child_t12';
    % ��Ǩ�Ƶ�֪ʶ
    for i=1:pop1
        GAN_t21(i).rnvec = GAN_child_t21(i,:);
        GAN_t12(i).rnvec = GAN_child_t12(i,:);
    end
    count=1;
    for i=1:pop1/2
        DE_t11(count)=Chromosome2;
        DE_t11(count+1)=Chromosome2;
        DE_t22(count)=Chromosome2;
        DE_t22(count+1)=Chromosome2;
        [DE_t11(count),DE_t11(count+1)] = IDE(population,prepop,population(count),population(count+1),pop1);
        [DE_t22(count),DE_t22(count+1)] = IDE(population,prepop,population(count+pop1),population(count+1+pop1),pop1);
        DE_t11(count).skill_factor=1;
        DE_t11(count+1).skill_factor=1;
        DE_t22(count).skill_factor=2;
        DE_t22(count+1).skill_factor=2;
        count=count+2;
    end
    for i = 1:pop % Performing binary tournament selection to create parent pool
        parent(i)=Chromosome2();
    end
    rndlist=randperm(pop);
    parent=population(rndlist);
    count=1;
    for i=1:2:pop % Create offspring population
        child(count)=Chromosome2;
        child(count+1)=Chromosome2;
        p1=i;
        p2=i+1;
        if parent(p1).skill_factor==parent(p2).skill_factor  %�����ڽ���
            if parent(p1).skill_factor==1
                child(count)=DE_t11(parent(p1).rank);
                child(count+1)=DE_t11(parent(p2).rank);
            else
                child(count)=DE_t22(parent(p1).rank);
                child(count+1)=DE_t22(parent(p2).rank);
            end
            
        else  % ����佻��
            if parent(p1).skill_factor==1
                c1=  GAN_t21(parent(p1).rank);
                c1.skill_factor=1;
                c2 = GAN_t12(parent(p2).rank);
                c2.skill_factor=2;
                [child(count),child(count+1)] = IDEafterGAN(c1,population_t1,c2,population_t2,prepop,pop1,population(1),population(pop1+1));
                child(count).skill_factor=1;
                child(count+1).skill_factor=2;
            else
                c1=  GAN_t12(parent(p1).rank);
                c1.skill_factor=2;
                c2= GAN_t21(parent(p2).rank);
                c2.skill_factor=1;
                [child(count),child(count+1)] = IDEafterGAN(c1,population_t2,c2,population_t1,prepop,pop1,population(1+pop1),population(1));
                child(count).skill_factor=2;
                child(count+1).skill_factor=1;
            end
        end
        count=count+2;
    end
    %�����Ӵ�
    for i=1:pop
        child(i).rnvec(child(i).rnvec>1)=1;
        child(i).rnvec(child(i).rnvec<0)=0;
        child(i).rnvec(isnan(child(i).rnvec))=rand(1);
        [child(i).obj(1) , child(i).obj(2)] = evaluate(child(i), Tasks(child(i).skill_factor));
    end
    prepop = population;
    population=reset(population,pop);
    intpopulation(1:length(population))=population;
    intpopulation(length(population)+1:length(population)+pop)=child;
    population(pop*2+1:end)=[];
    for i = 1:2
        popobj = [];
        population_subpop =intpopulation([intpopulation.skill_factor]==i);   %ѡ������Ⱥ
        for j = 1:length(population_subpop)
            popobj(j,:) = population_subpop(j).obj;
        end
        [ front, FrontNO,~] = NDSort(popobj,inf);
        for j = 1:length(population_subpop)
            population_subpop(j).front = FrontNO(j);
        end
        %crowing distance
        [population_subpop,~]=SolutionComparison.diversity(population_subpop,front,length(population_subpop...
            ),length(population_subpop(1).obj));
        population((i-1) * (pop1) +1 : i*(pop1)) = population_subpop(1:pop1);
    end
    %   ����ÿһ�������IGD---------------------------
    for i = 1:2
        data = vec2mat([population((i-1) * (pop1) +1 : i*(pop1)).obj],2);
        igd = calculate_IGD(data, Tasks(i));
        if  generation == 1
            IGD(i , generation) = igd;
        elseif igd < IGD(i,generation-1)
            IGD(i , generation) = igd;
        else
            IGD(i , generation) = IGD(i,generation - 1);
        end
    end
    %-------------------�������----------------------------
    generation = generation + 1;
    disp(['EMT-GS:' , num2str(generation),'pro:', num2str(IGD(1,generation-1) ),'   ', num2str(IGD(2,generation-1))]);
end

end