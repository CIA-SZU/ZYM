classdef Chromosome2
    
    properties
        XSnvec; 
        XCnvec;
        rnvec;
        obj;
        convio;
        skill_factor;
        front;%���ڵڼ���
        CD;
        rank;%��ʾ�ǵڼ�������
        dominationcount=0;
        dominatedset=[];
        dominatedsetlength=0;
        isparent=0;
        ischild=0;
        stra = 0;
        flag;
        immediateParent;
    end
    
    methods
        
        function object=initialize(object,dim)
            object.rnvec=(rand(1,dim));
        end
        
        function Gfunction = evalGfunction(Task , x)
            Xcov=x.rnvec(Task.boundaryCvDv+1:end);
            decodeXcov = (Task.Upper(Task.boundaryCvDv + 1:end) - Task.Low(Task.boundaryCvDv + 1:end)) ...
                .* Xcov + Task.Low(Task.boundaryCvDv + 1:end);

            %����ת��
          [good_gene] = boundaryPrevent(decodeXcov, Task.Low(Task.boundaryCvDv + 1:end) , ...
                Task.Upper(Task.boundaryCvDv + 1:end));
            switch Task.Gfunction
                case 'F4'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = decodeXcov .* (2.048/100);
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    %Rosenbrock
                    t = 0;
                    decodeXcov(1)=decodeXcov(1)+1;
                    for i = 1:length(decodeXcov)-1
                        decodeXcov(i+1)=decodeXcov(i+1)+1;
                        t = t +  100 * (decodeXcov(i)^2 - decodeXcov(i + 1))^2  + (1 - decodeXcov(i))^2;
                    end
                    Gfunction = t;
                case 'F8'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = decodeXcov .* (5.12/100);
                    %Rastrigin
                    a = 10 * length(decodeXcov);
                    Gfunction = sum(decodeXcov .^ 2 - 10 .* cos((2 * pi) .* decodeXcov)) + a;
                case 'F9'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = decodeXcov .* (5.12/100);
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    %Rastrigin
                    a = 10 * length(decodeXcov);
                    Gfunction = sum(decodeXcov .^ 2 - 10 .* cos(2 * pi .* decodeXcov)) + a;
                case 'F11'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = decodeXcov .* (1000.0/100);
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    %MSchwefel
                    prod1 = 0;
                    for i = 1: length(decodeXcov)
                        z=decodeXcov(i)+4.209687462275036e+002;
                        if abs(z)<=500
                            gz=z*sin(abs(z)^0.5);
                        elseif z>500
                            gz=(500-mod(z,500))*sin(abs(500-mod(z,500))^0.5) - ((z-500)^2)/(10000*length(decodeXcov));
                        else
                            gz=(mod(abs(z),500)-500)*sin(abs(500-mod(abs(z),500))^0.5) - ((z+500)^2)/(10000*length(decodeXcov));
                        end
                        prod1 = prod1 + gz;
                    end
                    Gfunction = 418.9829*length(decodeXcov)-prod1;
                case 'F15'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = decodeXcov .* (5.0/100);
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    %ExGriewRosen
                    decodeXcov(1) = decodeXcov(1)+1;
                    Gfunction = 0;
                    for i = 1:length(decodeXcov)-1
                        decodeXcov(i+1) = decodeXcov(i+1)+1;
                        t = 100 * ((decodeXcov(i)^2 - decodeXcov(i + 1))^2)  + (decodeXcov(i)-1)^2;
                        Gfunction=Gfunction+(t^2)/4000-cos(t)+1;
                    end
                    index=length(decodeXcov);
                    t = 100 * ((decodeXcov(index)^2 - decodeXcov(1))^2)  + (decodeXcov(index)-1)^2;
                    Gfunction=Gfunction+(t^2)/4000-cos(t)+1;
                case 'F17'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    D=length(decodeXcov);
                    n1=ceil(0.3*D);
                    n2=ceil(0.3*D);
                    n3=D-n1-n2;
                    x1=decodeXcov(1:n1);
                    x2=decodeXcov(n1+1:n1+n2);
                    x3=decodeXcov(n1+n2+1:D);
                    x1 = x1 .* (1000.0/100);
                    x2 = x2 .* (5.12/100);
                    %MSchwefel
                    prod1 = 0;
                    for i = 1: length(x1)
                        z=x1(i)+4.209687462275036e+002;
                        if abs(z)<=500
                            gz=z*sin(abs(z)^0.5);
                        elseif z>500
                            gz=(500-mod(z,500))*sin(abs(500-mod(z,500))^0.5) - ((z-500)^2)/(10000*length(x1));
                        else
                            gz=(mod(abs(z),500)-500)*sin(abs(500-mod(abs(z),500))^0.5) - ((z+500)^2)/(10000*length(x1));
                        end
                        prod1 = prod1 + gz;
                    end
                    Gfunction = 418.9829*length(x1)-prod1;
                    %Rastrigin
                    a = 10 * length(x2);
                    Gfunction = Gfunction+sum(x2 .^ 2 - 10 .* cos(2 * pi .* x2)) + a;
                    %Elliptic
                    a=10^6;
                    for i = 1 : n3
                        Gfunction = Gfunction+(a^((i-1)/(n3-1)))*(x3(i)^2);
                    end
                case 'F18'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    D=length(decodeXcov);
                    n1=ceil(0.3*D);
                    n2=ceil(0.3*D);
                    n3=D-n1-n2;
                    x1=decodeXcov(1:n1);
                    x2=decodeXcov(n1+1:n1+n2);
                    x3=decodeXcov(n1+n2+1:D);
                    x2 = x2 .* (5.0/100);
                    x3= x3 .* (5.12/100);
                    %Cigar
                    a = sum(x1(2:end).^2);
                    Gfunction = x1(1)^2+a*(10^6);
                    %HGBat
                    x2 = x2-1;
                    sum1=sum(x2.^2);
                    sum2=sum(x2);
                    Gfunction = Gfunction + (abs(sum1^2-sum2^2))^0.5+(0.5*sum1+sum2)/n2+0.5;
                    %Rastrigin
                    a = 10 * n3;
                    Gfunction = Gfunction+ sum(x3 .^ 2 - 10 .* cos(2 * pi .* x3)) + a;
                case 'F19'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    D=length(decodeXcov);
                    n1=ceil(0.2*D);
                    n2=ceil(0.2*D);
                    n3=ceil(0.3*D);
                    n4=D-n1-n2-n3;
                    x1=decodeXcov(1:n1);
                    x2=decodeXcov(n1+1:n1+n2);
                    x3=decodeXcov(n1+n2+1:n1+n2+n3);
                    x4=decodeXcov(n1+n2+n3+1:end);
                    x1 = x1 .* (600.0/100);
                    x2 = x2 .* (0.5/100);
                    x3 = x3 .* (2.048/100);
                    %Griewank
                    t = sqrt([1:n1]);
                    sum1 = sum(x1 .^ 2);
                    prod1 = prod(cos(x1 ./ t));
                    Gfunction = 1+ sum1 / 4000 - prod1;
                    %Weierstrass
                    a = 0.5;
                    b = 3;
                    kmax = 20;
                    part1=0;
                    for i = 1:n2
                        for k = 0:kmax
                            part1 = part1 + a^k*cos(2*pi*(b^k)*(x2(i)+0.5));
                        end
                    end
                    part2=0;
                    for k = 0:kmax
                        part2 = part2 + a^k*cos(2*pi*(b^k)*0.5);
                    end
                    Gfunction = Gfunction + part1 - n2*part2;
                    %Rosenbrock
                    t = 0;
                    x3(1)=x3(1)+1;
                    for i = 1:n3-1
                        x3(i+1)=x3(i+1)+1;
                        t = t +  100 * (x3(i)^2 - x3(i + 1))^2  + (1 - x3(i))^2;
                    end
                    Gfunction = Gfunction + t;
                    %ScafferF6
                    t=0;
                    for i = 1:n4
                        pSum=x4(i)^2+x4(mod(i,n4)+1)^2;
                        t=0.5+((sin(pSum^0.5))^2-0.5)/((1+0.001*pSum)^2);
                        Gfunction = Gfunction + t;
                    end
                case 'F20'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    D=length(decodeXcov);
                    n1=ceil(0.2*D);
                    n2=ceil(0.2*D);
                    n3=ceil(0.3*D);
                    n4=D-n1-n2-n3;
                    x1=decodeXcov(1:n1);
                    x2=decodeXcov(n1+1:n1+n2);
                    x3=decodeXcov(n1+n2+1:n1+n2+n3);
                    x4=decodeXcov(n1+n2+n3+1:end);
                    x1 = x1 .* (5.0/100);
                    x3 = x3 .* (5.0/100);
                    x4 = x4 .* (5.12/100);
                    %HGBat
                    x1 = x1-1; 
                    sum1=sum(x1.^2);
                    sum2=sum(x1);
                    Gfunction = (abs(sum1^2-sum2^2))^0.5+(0.5*sum1+sum2)/n1+0.5;
                    %Discus
                    Gfunction = Gfunction + (10^6)*(x2(1)^2)+sum(x2(2:end).^2);
                    %ExGriewRosen
                    x3(1) = x3(1)+1;
                    for i = 1:n3-1
                        x3(i+1) = x3(i+1)+1;
                        t = 100 * (x3(i)^2 - x3(i + 1))^2  + (x3(i)-1)^2;
                        Gfunction=Gfunction+(t^2)/4000-cos(t)+1;
                    end
                    t = 100 * (x3(length(x3))^2 - x3(1))^2  + (x3(length(x3))-1)^2;
                    Gfunction=Gfunction+(t^2)/4000-cos(t)+1;
                    %Rastrigin
                    a = 10 * length(x4);
                    Gfunction = Gfunction + sum(x4 .^ 2 - 10 .* cos(2 * pi .* x4)) + a;
                case 'F22'
                    decodeXcov = decodeXcov - Task.shift;
                    decodeXcov = Task.matrix * decodeXcov';
                    decodeXcov = decodeXcov';
                    D=length(decodeXcov);
                    n1=ceil(0.1*D);
                    n2=ceil(0.2*D);
                    n3=ceil(0.2*D);
                    n4=ceil(0.2*D);
                    n5=D-n1-n2-n3-n4;
                    x1=decodeXcov(1:n1);
                    x2=decodeXcov(n1+1:n1+n2);
                    x3=decodeXcov(n1+n2+1:n1+n2+n3);
                    x4=decodeXcov(n1+n2+n3+1:n1+n2+n3+n4);
                    x5=decodeXcov(n1+n2+n3+n4+1:end);
                    x1 = x1 .* (5.0/100);
                    x2 = x2 .* (5.0/100);
                    x3 = x3 .* (5.0/100);
                    x4 = x4 .* (1000.0/100);
                    %Katsuura
                    index=32;
                    prod1 = 0;
                    Gfunction=1;
                    for i = 1:n1
                        for j =1 : index
                            prod1=prod1+abs(2^(j)*x1(i)-round(2^(j)*x1(i)))/(2^(j));
                        end
                        Gfunction=Gfunction*((1+(i-1)*prod1)^(10/(n1^1.2)));
                    end
                    Gfunction=(10/(n1^1.2))*(Gfunction-1);
                    %HappyCat
                    x2=x2-1;
                    sum1=sum(x2.^2);
                    sum2=sum(x2);
                    Gfunction=Gfunction+abs(sum1-n2)^0.25+(0.5*sum1+sum2)/n2+0.5;
                    %ExGriewRosen
                    x3(1) = x3(1)+1;
                    for i = 1:n3-1
                        x3(i+1) = x3(i+1)+1;
                        t = 100 * ((x3(i)^2 - x3(i + 1))^2)  + (x3(i)-1)^2;
                        Gfunction=Gfunction+(t^2)/4000-cos(t)+1;
                    end
                    t = 100 * ((x3(length(x3))^2 - x3(1))^2)  + (x3(length(x3))-1)^2;
                    Gfunction=Gfunction+(t^2)/4000-cos(t)+1;
                    %MSchwefel
                    prod1 = 0;
                    for i = 1: length(x4)
                        z=x4(i)+4.209687462275036e+002;
                        if abs(z)<=500
                            gz=z*sin(abs(z)^0.5);
                        elseif z>500
                            gz=(500-mod(z,500))*sin(abs(500-mod(z,500))^0.5) - ((z-500)^2)/(10000*n4);
                        else
                            gz=(mod(abs(z),500)-500)*sin(abs(500-mod(abs(z),500))^0.5) - ((z+500)^2)/(10000*n4);
                        end
                        prod1 = prod1 + gz;
                    end
                    Gfunction = Gfunction + 418.9829*n4-prod1;
                    %Ackley
                    sum1 = sum(x5 .^ 2) / n5;
                    sum2 = sum(cos(2 * pi .* x5) ./ n5);
                    Gfunction = Gfunction + (-20) * exp(-0.2 * sqrt(sum1)) - exp(sum2) + 20 +exp(1);
                
            end
        end
        
        %-------------------�Զ����Ա����Ĵ�������-------------------------
        function F1Function = evalF1(Task , x)
            
            Xdiv=x.rnvec(1:Task.boundaryCvDv);
            decodeXdiv = (Task.Upper(1:Task.boundaryCvDv) - Task.Low(1:Task.boundaryCvDv)) ...
                .* Xdiv + Task.Low(1:Task.boundaryCvDv);
            
            if strcmp(Task.F1Function , 'linear')
                A = sum(decodeXdiv);
                F1Function = A / length(decodeXdiv);
            else
                A = sum(decodeXdiv .^ 2);
                F1Function = sqrt(sum(A));
            end
        end
        
        
      
        

        function [f1 , f2] = evaluate(object, Task)
            %decoding
            x=object.rnvec.*(Task.Upper-Task.Low)+Task.Low;
            switch Task.type
                case 'MMDTLZ'          
                    g = evalGfunction(Task, object);
                    f1 = (1+ g) * cos(x(1) * 0.5 * pi);
                    f2 = (1 + g) * sin(x(1) * 0.5 * pi);
                otherwise
                    f1 =  evalF1(Task,object);
                    g =  evalGfunction(Task, object);
                    g = g+1;
                    if strcmp(Task.Hfunction, 'convex')
                        f2 = g*(1 - sqrt((f1 / g)));
                    else
                        f2 = g*(1 - (f1 / g) ^ 2);
                    end
            end
        end
        
        function population=reset(population,pop)
            for i=1:pop
                population(i).dominationcount=0;
                population(i).dominatedset=[];
                population(i).dominatedsetlength=0;
            end
        end
    end
    
end

