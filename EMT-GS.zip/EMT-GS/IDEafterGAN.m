function [child1,child2] = IDEafterGAN(p1,DE_t11,p2,DE_t22,prepop,subpop,best1,best2)
%ADAPTIVENEWDE 此处显示有关此函数的摘要
%   此处显示详细说明
child1 = Chromosome2();
child2 = Chromosome2();
F=normrnd(0.5,0.2);

while F>1||F<0
    F=normrnd(0.5,0.2);
end
pp=0.5;
pCR=0.6;
sf1 = p1.skill_factor;
sf2 = p2.skill_factor;

subpopulation1=DE_t11;
subpopulation2=DE_t22;
prepopulation1=prepop((sf1-1)*subpop+1 : sf1*subpop);
prepopulation2=prepop((sf2-1)*subpop+1 : sf2*subpop);
if rand(1)>pp % rand
    r2=randi([1,subpop]);
    r1=randi([1,subpop]);
    while r1 == p1.rank
        r1=randi([1,subpop]);
    end
    tmp1= subpopulation1(r1);
    y1=tmp1.rnvec+F*(p1.rnvec-prepopulation1(r2).rnvec);
else % best
    r2=randi([1,subpop]);
    tmp1=best1;
    y1=best1.rnvec+F*(p1.rnvec-prepopulation1(r2).rnvec);
end
if rand(1)>pp % rand
    r2=randi([1,subpop]);
    r1=randi([1,subpop]);
    while r1 == p2.rank
        r1=randi([1,subpop]);
    end
    tmp2= subpopulation2(r1);
    y2=tmp2.rnvec+F*(p2.rnvec-prepopulation2(r2).rnvec);
else % best
    r2=randi([1,subpop]);
    tmp2=best2;
    y2=best2.rnvec+F*(p2.rnvec-prepopulation2(r2).rnvec);
end
%交叉
z=zeros(1,length(p1.rnvec)); % 初始化一个新个体
j0=randi([1,numel(p1.rnvec)]); % 产生一个伪随机数，即选取待交换维度编号
for j=1:numel(p1.rnvec) % 遍历每个维度
    if j==j0 || rand(1)<=pCR % 如果当前维度是待交换维度或者随机概率小于交叉概率
        z(j)=y1(j); % 新个体当前维度值等于中间体对应维度值
    else
        z(j)=tmp1.rnvec(j); % 新个体当前维度值等于当前个体对应维度值
    end
end
child1.rnvec = z;

z=zeros(1,length(p2.rnvec)); % 初始化一个新个体
j0=randi([1,numel(p2.rnvec)]); % 产生一个伪随机数，即选取待交换维度编号
for j=1:numel(p2.rnvec) % 遍历每个维度
    if j==j0 || rand(1)<=pCR % 如果当前维度是待交换维度或者随机概率小于交叉概率
        z(j)=y2(j); % 新个体当前维度值等于中间体对应维度值
    else
        z(j)=tmp2.rnvec(j); % 新个体当前维度值等于当前个体对应维度值
    end
end
child2.rnvec = z;

end

