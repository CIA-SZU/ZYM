function [IGD]=calculate_IGD(PopObj, Task)
load PF\concave.pf
load PF\convex.pf
load PF\circle.pf
switch Task.type
    case 'MMDTLZ'
        PF = circle;
    otherwise
        switch Task.Hfunction
            case 'concave'
                PF = concave;
            otherwise
                PF = convex;
        end
end
Distance = min(pdist2(PF,PopObj),[],2);
IGD = mean(Distance);
end

