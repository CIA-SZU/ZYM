clc
beep off
addpath(genpath(pwd));
IGD = {};
gen = 1000;% Maximum Number of generations
pop = 200;
for run=1:30
    for index = 1:10
        Tasks=benchmark(index);      
        [IGD{run,index} , ~] =  EMT_GS(Tasks,pop,gen,index);
    end
end

